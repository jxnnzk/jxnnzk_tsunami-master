Config = {}

Config.Groups = {
    'superadmin',
    'admin'
}

Config.StartCommand = 'tsunami'
Config.ResetCommand = 'tsunamireset'
Config.NoPermissions = '~r~Du hast keine Berechtigung, diesen Befehl auszuführen.'
