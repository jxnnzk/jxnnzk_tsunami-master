fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Jxnnzk'
description 'ESX Tsunami Script'
version '1.2.0'

escrow_ignore 'config.lua'

shared_script 'config.lua'
client_script 'client/main.lua'
server_script 'server/main.lua'

files {
	'stream/*.xml'
}

data_file 'WATER_FILE' 'stream/*.xml'
